package jni;

public class Demo {
    public native void sayHello(int x,int y);
}